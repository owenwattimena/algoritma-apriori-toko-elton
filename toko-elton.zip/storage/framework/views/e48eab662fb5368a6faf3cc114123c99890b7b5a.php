<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h6 class="card-title">Laporan Analisa Transaksi Penjualan dengan Algoritma Apriori</h6>
                <div class="row">
                    <div class="col-md-12">
                        <ul class="list-group mb-2">
                            <li class="list-group-item pb-0">
                                <form action="" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-2 mb-3">
                                            <label for="inputTanggal" class="form-label">Periode Awal</label>
                                            <input type="date" class="form-control form-control-sm" id="inputTanggal" name="periode_awal" value="<?php echo e($periode_awal ?? ''); ?>" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="inputTanggal" class="form-label">Periode Akhir</label>
                                            <input type="date" class="form-control form-control-sm" id="inputTanggal" name="periode_akhir" value="<?php echo e($periode_akhir ?? ''); ?>" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="inputTanggal" class="form-label">Min. Support</label>
                                            <input type="number" class="form-control form-control-sm" id="inputTanggal" name="min_sup" value="<?php echo e($min_sup); ?>" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="inputTanggal" class="form-label">Min. Confidence (%)</label>
                                            <input type="number" class="form-control form-control-sm" id="inputTanggal" name="min_conf" value="<?php echo e($min_conf); ?>" required>
                                        </div>
                                        <div class="col-md-2 mb-3">
                                            <label for="inputTanggal" class="form-label text-white">_</label>
                                            <button type="submit" class="form-control btn-sm btn btn-success">Analisa</button>
                                        </div>
                                    </div>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <?php if($result): ?>
                <h6 class="mt-5">Dataset</h6>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th style="width: 190px">Id Transaksi</th>
                                <th>Item Barang</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id_transaksi); ?></td>
                                <td>
                                    <?php $__currentLoopData = $item->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($detail->produk->nama_produk); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <h6 class="mt-5">Frekuensi Itemset</h6>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Itemset barang</th>
                            <th>Support Count</th>
                            <th>Support </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $result['freg_itemsets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php
                                $index = 1;
                                ?>
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $index +=1;
                                ?>
                                <?php echo e($key != 'sup' ? $i . ($index <= count($item) ? ',' : '') : ''); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($item['sup']); ?></td>
                            <td> <?php echo e(( $item['sup'] / count($transaksi) ) * 100); ?>% </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
                <h6 class="mt-5">Aturan Assosiatif</h6>
                <div class="table-responsive">
                    <table class="table table-sm" id="table">
                        <thead>
                            <tr>
                                <th>Aturan Asosiatif</th>
                                <th>Confidence</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $result['assoc_rules']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    { <?php echo e($key); ?> } → {
                                        <?php
                                        $index = 1;
                                        ?>
                                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $index +=1;
                                        ?>
                                        <?php echo e(($index <= count($item) ? '' : $k)); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    }
                                </td>
                                <td>
                                    <?php echo e(end($item)); ?>%
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <?php if(isset($no_data)): ?>
                <div class="alert alert-warning" role="alert">
                    <?php echo e($no_data); ?>

                </div>
                <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- Plugin js for this page -->
<script src="<?php echo e(url('/')); ?>/assets/vendors/datatables.net/jquery.dataTables.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js"></script>
<script>
$(function() {
        'use strict';

        $(function() {
            $('#table').DataTable({
                "aLengthMenu": [
                    [10, 30, 50, -1]
                    , [10, 30, 50, "All"]
                ]
                , "iDisplayLength": 10
                , "language": {
                    search: ""
                }
            });
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\toko-elton\resources\views/laporan/index.blade.php ENDPATH**/ ?>